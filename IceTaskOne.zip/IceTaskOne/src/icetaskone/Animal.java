/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package icetaskone;

import java.util.Scanner;

/**
 *
 * @author Amishka
 */
public class Animal {
    
    
    public int iDtag;
    public String species;

    public int getiDtag() {
        return iDtag;
    }

    public void setiDtag(int iDtag) {
        this.iDtag = iDtag;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }
    
    //Declaring variables
    private int iDtag;
    private String species;
    
    //Input method
        public void input() {
        Scanner kb = new Scanner(System.in);
        Animal animal = new Animal();
        
        System.out.print("Enter ID tag: ");
        iDtag = kb.nextInt();  //Populating variable IDtag
        animal.setiDtag(iDtag);
        kb.nextLine();
        System.out.print("Enter species: ");
        species = kb.nextLine();   //Populating variable species
        animal.setSpecies(species);
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
}// main ends
