/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package icetaskone;

import java.util.Scanner;

/**
 *
 * @author Amishka
 */
public class IceTaskOne {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Bird brd;

//Reptile rept;

//Creating a scanner to ask the user for input values
        Scanner kb = new Scanner(System.in);
        
        boolean correctInput = false;

        //Instantiate objects 'brd' and 'rept'
        Bird brd = new Bird();
        Reptile rept = new Reptile();

      
        System.out.println("Please enter one of the follwoing species: \"bird\" or \"reptile\": "); //Prompting the user to select one of the two animals
    
        //Using a while loop so if the incorrect values are entered it continues looping the user until the correct option/s are entered
        while (!correctInput) {
        String userInput = kb.next();   //Capturing the user input
        
        switch (userInput.toLowerCase()) {  //Using a switch as its neater than if statements
        case "reptile" ->
                {
                    System.out.println("\nEntering values for the following Species: Reptile");
                        rept.input();   //Calling the input method from child class 'Reptile' to ask the user to input values
                    System.out.println("\nReptile object values:");
                        rept.output();  //Calling the output method from child class 'Reptile' to display values
                    correctInput = true;    //Boolean is true therefore it exits the while loop
                }
        case "bird" ->
                {
                    System.out.println("Entering values for the following Species: Bird");
                        brd.input();    //Calling the input method from child class 'Reptile' to ask the user to input values
                    System.out.println("\nBird object values:");
                        brd.output();   //Calling the output method from child class 'Reptile' to display values
                    correctInput = true;    //Boolean is true therefore it exits the while loop
                }
        default -> System.out.println("Please enter only one of the following species: \"bird\" or \"reptile\": ");
        //Reprompt the user if incorreect values are entered
        //Boolean is still set to false
        }
      }
    }
   
    


}
